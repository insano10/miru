Command Line with maven:
1) mvn clean install jetty:run
2) ./scripts/gather/start-gather.sh src/resources/miru.properties
3) http://localhost:8080/miru

From release artifact:
1) Unpack Miru.tar.gz
2) ./miru-start-all.sh
3) http://localhost:8080


watch a project with:
./scripts/gather.sh <path to miru.properties>

start webapp with:
java -jar web/jetty-runner.jar web/miru-web.war



tar.gz deployment structure:

miru

-> miru-start-all.sh
-> miru-stop-all.sh

-> scripts
  -> gather
    -> gather.sh
    -> start-gather.sh


-> web
  -> jetty-runner.jar
  -> miru-web.war

-> properties
  -> miru.properties

